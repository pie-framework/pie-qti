# I9b - Response Processing Fixed Template

The Acceptance Criteria for each of these examples is found in their corresponding sub-directories.
