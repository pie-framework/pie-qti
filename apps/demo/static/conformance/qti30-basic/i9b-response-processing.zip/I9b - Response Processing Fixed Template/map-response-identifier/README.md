# I9b - Response Processing Fixed Template - Map Response Identifier

## Description

This QTI 3 Conformance Test Sample aims at testing the **I9b - Response Processing Fixed Template** feature. It focuses
on testing whether or not a Delivery Application is able to correctly run the QTI 3 **map_response** Response Processing Template
at end attempt time.

| I9b                   |   |
|-----------------------|---|
| **Test Sample ID**        | I9b-response-processing-fixed-template-map-response-identifier  |
| **Test Sample Title**     | I9b - Response Processing Fixed Template - Map Response Identifier |
| **Dependencies**          | Q2 - Choice Interaction, I1 - responseDeclaration, I2 - outcomeDeclaration |
| **Related Documentation** | [QTI ASI Model - Response Processing Templates](http://www.imsglobal.org/question/qtiv2p2p1/QTIv2p2p1-ASI-InformationModelv1p0/imsqtiv2p2p1_asi_v1p0_InfoModelv1p0.html#RPTemplate)|

## Acceptance Criteria
### EXPORT
* **I9-L1-E1**: Export an item with a qti-response-processing element with a "template" attribute that references a fixed template for a choice interaction (https://purl.imsglobal.org/spec/qti/v3p0/rptemplates/map_response.xml, https://purl.imsglobal.org/spec/qti/v3p0/rptemplates/match_correct.xml).
### IMPORT
* **I9-L1-I1**: Import the provided conformance content and retain the association of the item to the fixed template reference (or equivelant response processing code).
### DELIVERY

* I9-L1-D1: If the value of the **RESPONSE** Response Variable is set to **NULL** or an **empty Multiple Container** when ending the attempt, the value of the **SCORE** Outcome Variable is set to **0**.
* I9-L1-D2: If the value of the **RESPONSE** Response Variable is set to a Multiple Container **[choice_a]**, the value of the **SCORE** OutcomeVariable is set to **1**.
* I9-L1-D3: If the value of the **RESPONSE** Response Variable is set to a Multiple Container **[choice_b]**, the value of the **SCORE** OutcomeVariable is set to **2**.
* I9-L1-D4: If the value of the **RESPONSE** Response Variable is set to a Multiple Container **[choice_c]**, the value of the **SCORE** OutcomeVariable is set to **5**.
* I9-L1-D5: If the value of the **RESPONSE** Response Variable is set to a Multiple Container **[choice_d]**, the value of the **SCORE** OutcomeVariable is set to **0**.
* I9-L1-D6: If the value of the **RESPONSE** Response Variable is set to a Multiple Container **[choice_e]**, the value of the **SCORE** OutcomeVariable is set to **0**.
* I9-L1-D7: If the value of the **RESPONSE** Response Variable is set to a Multiple Container **[choice_a,choice_b]**, the value of the **SCORE** OutcomeVariable is set to **3**.
* I9-L1-D8: If the value of the **RESPONSE** Response Variable is set to a Multiple Container **[choice_b,choice_c]**, the value of the **SCORE** OutcomeVariable is set to **6**.
* I9-L1-D9:If the value of the **RESPONSE** Response Variable is set to a Multiple Container **[choice_c,choice_d]**, the value of the **SCORE** OutcomeVariable is set to **4**.
* I9-L1-D10:If the value of the **RESPONSE** Response Variable is set to a Multiple Container **[choice_d, choice_e, choice_f]**, the value of the **SCORE** OutcomeVariable is set to **0**.
* I9-L1-D11:If the value of the **RESPONSE** Response Variable is set to a Multiple Container **[choice_a, choice_b, choice_c, choice_d, choice_e, choice_f]**, the value of the **SCORE** OutcomeVariable is set to **0**.

* There are no acceptance criteria for authoring for this feature at this time.