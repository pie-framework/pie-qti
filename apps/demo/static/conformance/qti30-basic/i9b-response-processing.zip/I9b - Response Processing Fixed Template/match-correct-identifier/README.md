# I9b - Response Processing Fixed Template - Match Correct Identifier

## Description

This QTI 3 Conformance Test Sample aims at testing the **I9b - Response Processing Fixed Template** feature. It focuses on testing whether or not a Delivery Application is able to correctly run the QTI 3 **match_correct** Response Processing Template
at end attempt time.

| I9b                   |   |
|-----------------------|---|
| **Test Sample ID**        | i9b-response-processing-fixed-template-match_correct-identifier  |
| **Test Sample Title**     | I9b - Response Processing Fixed Template - Match Correct Identifier |
| **Dependencies**          | Q2 - Choice Interaction, I1 - responseDeclaration, I2 - outcomeDeclaration |
| **Related Documentation** | [QTI ASI Model - Response Processing Templates](http://www.imsglobal.org/question/qtiv2p2p1/QTIv2p2p1-ASI-InformationModelv1p0/imsqtiv2p2p1_asi_v1p0_InfoModelv1p0.html#RPTemplate)|

## Acceptance Criteria

* There are no additional IMPORT or EXPORT acceptance criteria for this content.

### DELIVERY

* I9-L1-D12: If the value of the **RESPONSE** Response Variable is set to **NULL** when ending the attempt, the value of the **SCORE** Outcome Variable is set to **0**.
* I9-L1-D13: If the value of the **RESPONSE** Response Variable is set to **choice_a** when ending the attempt, the value of the **SCORE** Outcome Variable is set to **1**.
* I9-L1-D14: If the value of the **RESPONSE** Response Variable is set to **choice_b** when ending the attempt, the value of the **SCORE** Outcome Variable is set to **0**.

* There are no acceptance criteria for authoring for this feature at this time.
