# Q2 - Choice Interaction - Multiple Cardinality

## Description

This QTI 3.0 Conformance Test Sample aims at testing the **Q2 - Choice Interaction** feature. It focuses
on testing whether or not a Delivery System is able to collect values with **Identifier** baseType and 
**Multiple** cardinality from a **Choice Interaction** at end attempt time.

| Q2                   |   |
|-----------------------|---|
| **Test Sample ID**        | q2-choice-interaction-multiple-cardinality  |
| **Test Sample Title**     | Q2 - Choice Interaction - Multiple Cardinality |
| **Dependencies**          | I1 - responseDeclaration, I2 - outcomeDeclaration, I7 - Item Body |
| **Related Documentation** | [QTI ASI Model - Choice Interaction]|

## Acceptance Criteria
### EXPORT
* **Q2-L1-E1** Export a valid item with a Choice Interaction where the response declaration has a cardinality of "multiple".
* **Q2-L1-E2** Export a valid item with a Choice Interaction where there are at least 2 simple choices are provided that are uniquely identified within the item.

### IMPORT

* **Q2-L1-I1** Import multiple-cardinality.xml and correctly store the interaction as a choice interaction that allows for multiple selections.
* **Q2-L1-I2** Import multiple-cardinality.xml and correctly stores the choices and uniquely identifies them within the item.
* **Q2-L1-I3** Import multiple-cardinality.xml and correctly store the number of max-choices and min-choices.

#### Shared Vocabulary Classes Acceptance Criteria for IMPORT

* Q2-L1-I102: For file multiple-cardinality.xml File **multiple-cardinality-sv-2a.xml** uses the class **qti-labels-lower-alpha** in the qti-choice-interaction element which MUST be stored in association with the interaction.  
* Q2-L1-I103: File **multiple-cardinality-sv-2b.xml** uses the class **qti-labels-upper-alpha** in the qti-choice-interaction element which MUST be stored in association with the interaction.
* Q2-L1-D104: File **multiple-cardinality-sv-2c.xml** uses the class **qti-labels-decimal** in the qti-choice-interaction element which MUST be stored in association with the interaction.
* Q2-L1-D105:  File **multiple-cardinality-sv-2d.xml** uses the class **qti-labels-none** in the qti-choice-interaction element which MUST be stored in association with the interaction.

* Q2-L1-D106:  File **multiple-cardinality-sv-3a.xml** uses the classes **qti-labels-lower-alpha** and **qti-labels-suffix-parenthesis** in the qti-choice-interaction element which MUST be stored in association with the interaction.
* Q2-L1-D107:  File **multiple-cardinality-sv-3b.xml** uses the classes **qti-labels-lower-alpha** and **qti-labels-suffix-period** in the qti-choice-interaction element which MUST be stored in association with the interaction.
* Q2-L1-D108:  File **multiple-cardinality-sv-3c.xml** uses the classes **qti-labels-lower-alpha** and **qti-labels-suffix-none** in the qti-choice-interaction element which MUST be stored in association with the interaction.
* Q2-L1-D109:  File **multiple-cardinality-sv-3d.xml** uses the classes **qti-labels-upper-alpha** and **qti-labels-suffix-parenthesis** in the qti-choice-interaction element which MUST be stored in association with the interaction.
* Q2-L1-D110: File **multiple-cardinality-sv-3e.xml** uses the classes **qti-labels-upper-alpha** and **qti-labels-suffix-period** in the qti-choice-interaction element which MUST be stored in association with the interaction.
* Q2-L1-D111: File **multiple-cardinality-sv-3f.xml** uses the classes **qti-labels-upper-alpha** and **qti-labels-suffix-none** in the qti-choice-interaction element which MUST be stored in association with the interaction.

* Q2-L1-D112: File **multiple-cardinality-sv-3g.xml** uses the classes **qti-labels-decimal** and **qti-labels-suffix-parenthesis** in the qti-choice-interaction element which MUST be stored in association with the interaction.
* Q2-L1-D113: File **multiple-cardinality-sv-3h.xml** uses the classes **qti-labels-decimal** and **qti-labels-suffix-period** in the qti-choice-interaction element which MUST be stored in association with the interaction.
* Q2-L1-D114: File **multiple-cardinality-sv-3i.xml** uses the classes **qti-labels-decimal** and **qti-labels-suffix-none** in the qti-choice-interaction element which MUST be stored in association with the interaction.

* Q2-L1-I115: File **multiple-cardinality-sv-3j.xml** uses the class **qti-labels-suffix-none** in the qti-choice-interaction element  qti-choice-interaction element which MUST be stored in association with the interaction.
* Q2-L1-D116: File **multiple-cardinality-sv-3k.xml** uses the class **qti-labels-suffix-period** in the qti-choice-interaction element  which MUST be stored in association with the interaction.
* Q2-L1-I117: File **multiple-cardinality-sv-3l.xml** uses the class **qti-labels-suffix-parenthesis** in the qti-choice-interaction element which MUST be stored in association with the interaction.


### AUTHORING

* Q2-L1-A1: Create an item interaction that has at least three answer choices, of which at least two are correct responses. 
* Q2-L1-A2: Modify an item interaction that has at least three answer choices, of which at least two are correct responses.
* Q2-L1-A3: For a choice interaction with multiple selections possible, the ability to set the minimum number of choices allowed.
* Q2-L1-A4: For a choice interaction with multiple selections possible, the ability to set the maximum number of choices allowed.

### DELIVERY
* Q2-L1-D1: For file multiple-cardinality.xml after ending the attempt without selecting any SimpleChoices, the **RESPONSE** Response Variable is set with the **NULL** value OR an **empty Multiple Container**.
* Q22-L1-D2: For file multiple-cardinality.xml after ending the attempt with the SimpleChoice with identifier **choice_a** selected, the **RESPONSE** Response Variable is set with a **Multiple Container** containing a value **choice_a**, with an **Identifier** baseType.
* Q22-L1-D3: For file multiple-cardinality.xml after ending the attempt with the SimpleChoice with identifier **choice_b** selected, the **RESPONSE** Response Variable is set with a **Multiple Container** containing a value **choice_b**, with an **Identifier** baseType.
* Q22-L1-D4: For file multiple-cardinality.xml After ending the attempt with the SimpleChoice with identifier **choice_c** selected, the **RESPONSE** Response Variable is set with a **Multiple Container** containing a value **choice_c**, with an **Identifier** baseType.
* Q22-L1-D5: For file multiple-cardinality.xml After ending the attempt with the SimpleChoices with identifiers **choice_a** and **choice_b** selected, the **RESPONSE** Response Variable is set with a **Multiple Container** containing values **choice_a** and **choice_b**, with an **Identifier** baseType.
* Q22-L1-D6: For file multiple-cardinality.xml After ending the attempt with the SimpleChoices with identifiers **choice_b** and **choice_c** selected, the **RESPONSE** Response Variable is set with a **Multiple Container** containing values **choice_b** and **choice_c**, with an **Identifier** baseType.
* Q22-L1-D7: For file multiple-cardinality.xml After ending the attempt with the SimpleChoices with identifiers **choice_a**, **choice_b**, and **choice_c** selected, the **RESPONSE** Response Variable is set with a **Multiple Container** containing values **choice_a**, **choice_b** and **choice_c**, with an **Identifier** baseType.

#### Shared Vocabulary Classes Acceptance Criteria for DELIVERY

The qti-choice-interaction has a considerable amount of its shared vocabulary dedicated to the presentation/layout of the interaction’s associated qti-simple-choices. Each qti-simple-choice consists of a collection of elements, displayed from left to right, defined as follows:

1. A “control”; e.g., either a radio button or checkbox control, and
2. A “label”; e.g., often an alphanumeric character such as, “A”, “B”, “1”, “2”, etc., and
3. A “label suffix”; e.g., a “.” or “)” character after the label, and
4. A “description”; e.g., the HTML content contained by a qti-simple-choice element 

By default, in the absence of any shared vocabulary, the presentation of each choice control, label, label suffix, and description, is left to the implementer, with the only requirement that the choices are displayed in a single column, vertically oriented.


* Q2-L1-D101: File **multiple-cardinality-sv-1.xml** does not use any of the "qti-labels- " or "qti-labels-suffix- " classes in the qti-choice-interaction element. When the example is visually presented, any visually presented labels or label suffix are at the discretion of the delivery platform.  

* Q2-L1-D102: File **multiple-cardinality-sv-2a.xml** uses the class **qti-labels-lower-alpha** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in lower-case alphabetically ascending order (e.g., a b c  etc.). In this example, the label suffix is not specified and is at the discretion of the delivery platform.
* Q2-L1-D103: File **multiple-cardinality-sv-2b.xml** uses the class **qti-labels-upper-alpha** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in upper-case alphabetically ascending order (e.g., A B C  etc.). In this example, the label suffix is not specified and is at the discretion of the delivery platform.
* Q2-L1-D104: File **multiple-cardinality-sv-2c.xml** uses the class **qti-labels-decimal** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in numerically ascending order (e.g., 1 2 3  etc.). In this example, the label suffix is not specified and is at the discretion of the delivery platform.
* Q2-L1-D105:  File **multiple-cardinality-sv-2d.xml** uses the class **qti-labels-none** in the qti-choice-interaction element. When the example is visually presented it MUST NOT display any visual labels (often an alphanumeric character) or label suffixes (often a symbol after the label) associated with any of the simple-choices.

* Q2-L1-D106:  File **multiple-cardinality-sv-3a.xml** uses the classes **qti-labels-lower-alpha** and **qti-labels-suffix-parenthesis** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in lower-case alphabetically ascending order (e.g., a b c  etc.) followed by a label suffix, which MUST display as a closing parenthesis character ")" .
* Q2-L1-D107:  File **multiple-cardinality-sv-3b.xml** uses the classes **qti-labels-lower-alpha** and **qti-labels-suffix-period** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in lower-case alphabetically ascending order (e.g., a b c  etc.) followed by a label suffix, which MUST display as a period character "." .
* Q2-L1-D108:  File **multiple-cardinality-sv-3c.xml** uses the classes **qti-labels-lower-alpha** and **qti-labels-suffix-none** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in lower-case alphabetically ascending order (e.g., a b c  etc.). In this example, the label MUST NOT display any label suffix.
* Q2-L1-D109:  File **multiple-cardinality-sv-3d.xml** uses the classes **qti-labels-upper-alpha** and **qti-labels-suffix-parenthesis** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in upper-case alphabetically ascending order (e.g., A B C  etc.). In this example, the label suffix MUST display as a closing parenthesis character ")" .
* Q2-L1-D110: File **multiple-cardinality-sv-3e.xml** uses the classes **qti-labels-upper-alpha** and **qti-labels-suffix-period** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in lower-case alphabetically ascending order (e.g., A B C  etc.) followed by a label suffix, which MUST display as a period character "." .
* Q2-L1-D111: File **multiple-cardinality-sv-3f.xml** uses the classes **qti-labels-upper-alpha** and **qti-labels-suffix-none** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in lower-case alphabetically ascending order (e.g., A B C  etc.) followed by a label suffix, which MUST NOT display any label suffix.

* Q2-L1-D112: File **multiple-cardinality-sv-3g.xml** uses the classes **qti-labels-decimal** and **qti-labels-suffix-parenthesis** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in numerically ascending order (e.g., 1 2 3  etc.). In this example, the label suffix MUST display as a closing parenthesis character ")" .
* Q2-L1-D113: File **multiple-cardinality-sv-3h.xml** uses the classes **qti-labels-decimal** and **qti-labels-suffix-period** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in numerically ascending order (e.g., 1 2 3  etc.) followed by a label suffix, which MUST display as a period character "." .
* Q2-L1-D114: File **multiple-cardinality-sv-3i.xml** uses the classes **qti-labels-decimal** and **qti-labels-suffix-none** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in numerically ascending order (e.g., 1 2 3  etc.) followed by a label suffix, which MUST NOT display any label suffix.

* Q2-L1-D115: File **multiple-cardinality-sv-3j.xml** uses the class **qti-labels-suffix-none** in the qti-choice-interaction element. When the example is visually presented it MUST NOT display any visual suffix labels associated with any of the simple-choices. In this example, the label is not specified and is at the discretion of the delivery platform.  
* Q2-L1-D116: File **multiple-cardinality-sv-3k.xml** uses the class **qti-labels-suffix-period** in the qti-choice-interaction element. When the example is visually presented it MUST display visual suffix labels associated with the simple-choice options as a period character ".". In this example, the label is not specified and is at the discretion of the delivery platform.
* Q2-L1-D117: File **multiple-cardinality-sv-3l.xml** uses the class **qti-labels-suffix-parenthesis** in the qti-choice-interaction element. When the example is visually presented it MUST display visual suffix labels associated with the simple-choice options as a closing parenthesis character ")". In this example, the label is not specified and is at the discretion of the delivery platform.
