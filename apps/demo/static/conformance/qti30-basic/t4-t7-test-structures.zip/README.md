# T4, T7 - Basic Level Test Structures

## Description

This QTI 3.0 Conformance Test Sample aims to test the **T4 - Test Part** and **T7 – Section in Test Part** feature. It enables vendors to
validate the Delivery applications's ability to deal with the essential test-level structures: Test --> Part --> Section --> Item.

| T4, T7 and T14- Entry Level Test Structures |   |
|-----------------------|---|
| **Test Sample ID**        | T4 & T7 - Test Part and Section |
| **Test Sample Title**     | T4 & T7 - Test Part and Section |
| **Dependencies**          | T4 - Test Parts, T7 - Section in Test Part, I - Items  |
| **Related Documentation** | Section 4 of the QTI 3.0 Best Practices and Implementation Guide |

## Acceptance Criteria
### EXPORT
The application system must be able to export a test with:
  * **T4-L1-E1**: Export a package with a valid AssessmentTest with identifier and title attributes
  * **T4-L1-E2**: Export a package with a valid TestPart in an AssessmentTest with attributes: identifier, navigation-mode, submission-type 
  * **T7-L1-E1**: Export a package with at least one valid Section Element in a TestPart with attributes: identifier, title, visible
  * **T7-L1-E2**: Export a package with at least one Assessment Item referenced in a Section using qti-assessment-item-ref with attributes: identifier, href
### IMPORT
The application must be able to store test structure information related to the conformance test package:
  * **T4-L1-I1**: Import One AssessmentTest with identifier and title attributes
  * **T4-L1-I2**: Import One TestPart with identifier, navigation-mode, submission-type stored in association with the TestPart

  * **T7-L1-I1**: Import One Section Element with attributes identifier, title, visible
  * **T7-L1-I2**: Import 4 items in association with the Section that references them.

### AUTHORING
* T4-L1-A1: Create a test that has an identifier.
* T4-L1-A2: Modify a test that has an identifier.
* T4-L1-A3: Create a test that has a title.
* T4-L1-A4: Modify a test that has a title.

* T7-L1-A1: Create a test section that has one or more items.
* T7-L1-A2: Modify a test section that has one or more items.
* T7-L1-A3: Create a test section with a title.
* T7-L1-A4: Modify a test section title.
* T7-L1-A5: Create a test section with an identifier (separate from title).
* T7-L1-A6: Modify a test section identifier.

### DELIVERY

The delivery application must be capable of rendering tests and their constituient parts including:
  * **T4-L1-D1**: one Test Element
  * **T4-L1-D2**: one Part Element, where the navigation-mode is linear and the submission-type is individual

  * **T7-L1-D1**: one Section Element which is visible
  * **T7-L1-D2**: four Item Elements containing: ChoiceInteraction - single cardinality, ChoiceInteraction - multiple cardinality, TextEntryInteraction, and ExtendedTextInteraction 
  * **T14-L1-D1**: Record and Restore Responses. A candidates responses are correctly saved. When the session is discontinued and reinitiated the candidate’s responses are restored correctly.
