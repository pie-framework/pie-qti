# Q20 - Text Entry Interaction - BaseType String

## Description

This QTI 3.0 Conformance Test Sample aims at testing the **Q20 - Text Entry Interaction** feature. It focuses
on testing whether or not a Delivery application is able to collect values with **String** baseType and 
**Single** cardinality from a **Text Entry Interaction** at end attempt time.

**Known Invalid Example error:** contains extraneous "error rogue text" on the last line of the file.

| Q20                   |   |
|-----------------------|---|
| **Test Sample ID**        | q20-text-entry-base-type-string  |
| **Test Sample Title**     | Q20 - Text Entry Interaction - BaseType String |
| **Dependencies**          | I1 - responseDeclaration, I7 - Item Body | 
| **Related Documentation** | [QTI ASI Model - Text Entry Interaction](https://www.imsglobal.org)|

## Acceptance Criteria
### EXPORT
* Q20-L1-E1: export a valid instance of an assessment item with qti-text-entry-interaction with response-identifier attribute.

### IMPORT
* Q20-L1-I1: import base-type-string.xml and store as text entry interaction type.
* Q20-L1-I2: import text-entry.sv-3.xml and store pattern mask as (0-9.]{0,6})

* Q20-L1-I11: **Invalid Example** -- for file base-type-string-invalid.xml, the system should throw an XML validation exception.

#### Acceptance Criteria for Shared Vocabulary for IMPORT

* Q20-L1-I101: File **text-entry-sv-1.xml** does not use any of the "qti-input-width-#" classes in the qti-text-entry-interaction element. No classes should be stored for this item.  

* Q20-L1-I102: File **text-entry-sv-2a.xml** uses the class **qti-input-width-1** in the qti-text-entry-interaction element which MUST be stored in association with the text entry interaction.  

* Q20-L1-I103: File **text-entry-sv-2b.xml** uses the class **qti-input-width-2** in the qti-text-entry-interaction element. which MUST be stored in association with the text entry interaction.  

* Q20-L1-I104: File **text-entry-sv-2c.xml** uses the class **qti-input-width-3** in the qti-text-entry-interaction element which MUST be stored in association with the text entry interaction. 

* Q20-L1-I105: File **text-entry-sv-2d.xml** uses the class **qti-input-width-4** in the qti-text-entry-interaction element which MUST be stored in association with the text entry interaction. 

* Q20-L1-I112: File **text-entry-sv-2j.xml** uses the class **qti-input-width-5** in the qti-text-entry-interaction element which MUST be stored in association with the text entry interaction. 

* Q20-L1-I106: File **text-entry-sv-2e.xml** uses the class **qti-input-width-6** in the qti-text-entry-interaction element which MUST be stored in association with the text entry interaction.

* Q20-L1-I107: File **text-entry-sv-2f.xml** uses the class **qti-input-width-10** in the qti-text-entry-interaction element which MUST be stored in association with the text entry interaction.

* Q20-L1-I108: File **text-entry-sv-2g.xml** uses the class **qti-input-width-15** in the qti-text-entry-interaction element which MUST be stored in association with the text entry interaction.  

* Q20-L1-I109: File **text-entry-sv-2h.xml** uses the class **qti-input-width-20** in the qti-text-entry-interaction element which MUST be stored in association with the text entry interaction. 

* Q20-L1-I113: File **text-entry-sv-2k.xml** uses the class **qti-input-width-25** in the qti-text-entry-interaction element which MUST be stored in association with the text entry interaction. 

* Q20-L1-I114: File **text-entry-sv-2l.xml** uses the class **qti-input-width-30** in the qti-text-entry-interaction element which MUST be stored in association with the text entry interaction. 

* Q20-L1-I115: File **text-entry-sv-2m.xml** uses the class **qti-input-width-35** in the qti-text-entry-interaction element which MUST be stored in association with the text entry interaction. 

* Q20-L1-I116: File **text-entry-sv-2n.xml** uses the class **qti-input-width-40** in the qti-text-entry-interaction element which MUST be stored in association with the text entry interaction. 

* Q20-L1-I117: File **text-entry-sv-2o.xml** uses the class **qti-input-width-45** in the qti-text-entry-interaction element which MUST be stored in association with the text entry interaction. 

* Q20-L1-I118: File **text-entry-sv-2p.xml** uses the class **qti-input-width-50** in the qti-text-entry-interaction element which MUST be stored in association with the text entry interaction. 

* Q20-L1-I110: File **text-entry-sv-2i.xml** uses the class **qti-input-width-72** in the qti-text-entry-interaction element which MUST be stored in association with the text entry interaction.  

* Q20-L1-I111: File **text-entry-sv-3.xml** uses the attribute **data-patternmask-message** in the qti-text-entry-interaction element which MUST be stored in association with the text entry interaction.

### AUTHORING
* Q20-L1-A1: Create an inline interaction within an item that allows for input by the candidate in the form of text. 
* Q20-L1-A2: Modify an inline interaction within an item that allows for input by the candidate in the form of text. 
* Q20-L1-A3: For an inline text entry interaction, the response area must be able to allow for inline text adjacent to the response area.

### DELIVERY

* Q20-L1-D1: for file base-type-string.xml After ending the attempt without entering text in the input field, the **RESPONSE** Response Variable is set with the **NULL** value or with a value of **""** (empty string) with a **String** baseType and **Single** cardinality.
* Q20-L1-D2: for file base-type-string.xml After ending the attempt with the text "jumped" in the input field, the **RESPONSE** Response Variable is set with a value of **jumped**, with a **String** baseType and a **Single** cardinality.

#### Acceptance Criteria for Shared Vocabulary for DELIVERY

* Q20-L1-D101: File **text-entry-sv-1.xml** does not use any of the "qti-input-width-#" classes in the qti-text-entry-interaction element. When the example is visually presented, the width of the text entry input area is at the discretion of the delivery platform.  

* Q20-L1-D102: File **text-entry-sv-2a.xml** uses the class **qti-input-width-1** in the qti-text-entry-interaction element. When the example is visually presented it MUST display the text input area **at least** 1 character wide.  

* Q20-L1-D103: File **text-entry-sv-2b.xml** uses the class **qti-input-width-2** in the qti-text-entry-interaction element. When the example is visually presented it MUST display the text input area **at least** 2 characters wide.  

* Q20-L1-D104: File **text-entry-sv-2c.xml** uses the class **qti-input-width-3** in the qti-text-entry-interaction element. When the example is visually presented it MUST display the text input area **at least** 3 characters wide. 

* Q20-L1-D105: File **text-entry-sv-2d.xml** uses the class **qti-input-width-4** in the qti-text-entry-interaction element. When the example is visually presented it MUST display the text input area **at least** 4 characters wide. 

* Q20-L1-D112: File **text-entry-sv-2j.xml** uses the class **qti-input-width-5** in the qti-text-entry-interaction element. When the example is visually presented it MUST display the text input area **at least** 4 characters wide. 

* Q20-L1-D106: File **text-entry-sv-2e.xml** uses the class **qti-input-width-6** in the qti-text-entry-interaction element. When the example is visually presented it MUST display the text input area **at least** 6 characters wide.

* Q20-L1-D107: File **text-entry-sv-2f.xml** uses the class **qti-input-width-10** in the qti-text-entry-interaction element. When the example is visually presented it MUST display the text input area **at least** 10 characters wide.

* Q20-L1-D108: File **text-entry-sv-2g.xml** uses the class **qti-input-width-15** in the qti-text-entry-interaction element. When the example is visually presented it MUST display the text input area **at least** 15 characters wide.  

* Q20-L1-D109: File **text-entry-sv-2h.xml** uses the class **qti-input-width-20** in the qti-text-entry-interaction element. When the example is visually presented it MUST display the text input area **at least** 20 characters wide. 

* Q20-L1-D113: File **text-entry-sv-2k.xml** uses the class **qti-input-width-25** in the qti-text-entry-interaction element. When the example is visually presented it MUST display the text input area **at least** 25 characters wide.

* Q20-L1-D114: File **text-entry-sv-2l.xml** uses the class **qti-input-width-30** in the qti-text-entry-interaction element. When the example is visually presented it MUST display the text input area **at least** 30 characters wide.

* Q20-L1-D115: File **text-entry-sv-2m.xml** uses the class **qti-input-width-35** in the qti-text-entry-interaction element. When the example is visually presented it MUST display the text input area **at least** 35 characters wide.

* Q20-L1-D116: File **text-entry-sv-2n.xml** uses the class **qti-input-width-40** in the qti-text-entry-interaction element. When the example is visually presented it MUST display the text input area **at least** 40 characters wide.

* Q20-L1-D117: File **text-entry-sv-2o.xml** uses the class **qti-input-width-45** in the qti-text-entry-interaction element. When the example is visually presented it MUST display the text input area **at least** 45 characters wide.

* Q20-L1-D118: File **text-entry-sv-2p.xml** uses the class **qti-input-width-50** in the qti-text-entry-interaction element. When the example is visually presented it MUST display the text input area **at least** 50 characters wide.

* Q20-L1-D110: File **text-entry-sv-2i.xml** uses the class **qti-input-width-72** in the qti-text-entry-interaction element. When the example is visually presented it MUST display the text input area **at least** 72 characters wide.  

* Q20-L1-D111: File **text-entry-sv-3.xml** uses the attribute **data-patternmask-message** in the qti-text-entry-interaction element. The message MUST be presented by the delivery platform upon violation of pattern mask constraints.
