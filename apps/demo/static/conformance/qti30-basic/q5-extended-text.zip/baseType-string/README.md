# Q5 - Extended Text Interaction - BaseType String

## Description

This QTI 3.0 Conformance Test Sample aims at testing the **Q5 - Extended Text Interaction** feature. It focuses
on testing whether or not a Delivery application is able to collect values with **String** baseType and 
**Single** cardinality from an **Extended Text Interaction** at end attempt time.

**Known Invalid Example error:** the namespace declaration is incorrect xmlns="http://www.imsglobal.org/xsd/imsqti_v2p1" should be xmlns="http://www.imsglobal.org/xsd/imsqtiasi_v3p0".

| Q6                   |   |
|-----------------------|---|
| **Test Sample ID**        | q5-extended-text-base-type-string  |
| **Test Sample Title**     | Q5 - Extended Text Interaction - BaseType String |
| **Dependencies**          | I1 - responseDeclaration, I7 - Item Body |
| **Related Documentation** | [QTI ASI Model - Text Entry Interaction](https://www.imsglobal.org)|

## Acceptance Criteria
### EXPORT
* Q5-L1-E1: export an assessment item with interaction type qti-extended-text-interaction with a response-identifier attribute.

### IMPORT
* Q5-L1-I1: import base-type-string.xml as an extended text interaction with a unique identifier for the item.
* Q5-L1-I11: **Invalid Example**  for file base-type-string-invalid.xml -- the application MUST throw an XML namespace validation exception

#### Acceptance Criteria for Shared Vocabulary for IMPORT

* Q5-L1-I101: File **extended-text-entry-sv-1.xml** does not use any of the "qti-height-lines-#" classes in the qti-text-entry-interaction element so no classes should be stored with the interaction.  

* Q5-L1-I102: File **extended-text-entry-sv-2a.xml** uses the class **qti-height-lines-3** in the qti-text-entry-interaction element which MUST be stored in association with the interaction.  

* Q5-L1-I103: File **extended-text-entry-sv-2b.xml** uses the class **qti-height-lines-6** in the qti-text-entry-interaction element which MUST be stored in association with the interaction.  

* Q5-L1-I104: File **extended-text-entry-sv-2c.xml** uses the class **qti-height-lines-15** in the qti-text-entry-interaction element which MUST be stored in association with the interaction.

### AUTHORING
* Q5-L1-A1: Create a block interaction within an item that allows for input by the candidate in the form of text.
* Q5-L1-A2: Modify a block interaction within an item that allows for input by the candidate in the form of text.
* Q5-L1-A3: The response area must be a block, and does not allow text or other objects adjacent to the response area (the response area is not “inline”).
* Q5-L1-A4: The response area must allow for multiple lines of text entry. NOTE, it is NOT a requirement that ALL extended text entries authored within the application allow for multiple lines of input.

### DELIVERY

* Q5-L1-D1: for file base-type-string.xml after ending the attempt without entering text in the input field, the **RESPONSE** Response Variable is set with the **NULL** value or a value of **""** (empty string) with an String **baseType** and Single **cardinality**.
* Q5-L1-D2: for file base-type-string.xml after ending the attempt with any text in the text area field, the **RESPONSE** Response Variable is set with a value that matches the text entered, with an **String** baseType and a **Single** cardinality.



#### Acceptance Criteria for Shared Vocabulary for Delivery

* Q5-L1-D101: File **extended-text-entry-sv-1.xml** does not use any of the "qti-height-lines-#" classes in the qti-text-entry-interaction element. When the example is visually presented, the width of the text entry input area is at the discretion of the delivery platform.  

* Q5-L1-D102: File **extended-text-entry-sv-2a.xml** uses the class **qti-height-lines-3** in the qti-text-entry-interaction element. When the example is visually presented it MUST display the text input area **at least** 3 lines high.  

* Q5-L1-D103: File **extended-text-entry-sv-2b.xml** uses the class **qti-height-lines-6** in the qti-text-entry-interaction element. When the example is visually presented it MUST display the text input area **at least** 6 lines high.  

* Q5-L1-D104: File **extended-text-entry-sv-2c.xml** uses the class **qti-height-lines-15** in the qti-text-entry-interaction element. When the example is visually presented it MUST display the text input area **at least** 15 lines high.  
