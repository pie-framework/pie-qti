# A1 - Alternate Text for Graphics

## Description

This QTI 3.0.1 Conformance Test Sample aims at testing the **A1 - Alternate text for Graphics** feature. It focuses on ensuring that systems correctly import the alternate text and have that text available to candidates during item delivery.

| A1                  |   |
|-----------------------|---|
| **Test Sample ID**        | A1   |
| **Test Sample Title**     | Alternate Text for Graphics |
| **Dependencies**          | Q5 - Extended Text Interaction, I7 - Item Body |

## Acceptance Criteria
### EXPORT
* **A1-L1-E1**: alternate text for graphics in the img element are stored in the alt attribute for img.
### IMPORT
* **A1-L1-I1** alternate text for graphics remain associated with image.
### DELIVERY
* **A1-L1-D1**: the presentation markup for graphics in img have alternate text contained within the alt attribute (e.g. alt text content is available for assistive technology)


