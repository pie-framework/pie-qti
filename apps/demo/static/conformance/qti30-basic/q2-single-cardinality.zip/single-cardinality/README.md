# Q2 - Choice Interaction - Single Cardinality

## Description

This QTI 3.0 Conformance Test Sample aims at testing the **Q2 - Choice Interaction** feature. It primarily focuses on testing whether or not a Delivery Application is able to collect values with **Identifier** baseType and 
**Single** cardinality from a **Choice Interaction** at end attempt time.

**Known Invalid Example error:** This file is missing the closing, greater than symbol in the opening XML tag. 

| Q2                   |   |
|-----------------------|---|
| **Test Sample ID**        | q2-choice-interaction-single-cardinality  |
| **Test Sample Title**     | Q2 - Choice Interaction - Single Cardinality |
| **Dependencies**          | I1 - responseDeclaration |
| **Related Documentation** | [QTI ASI Model - Choice Interaction](https://www.imsglobal.org)|

## Acceptance Criteria

### EXPORT
* Q2-L1-E21: Export a valid item with a Choice Interaction where the response declaration has a cardinality of "single".
* Q2-L1-E22: Export a valid item with a Choice Interaction where there are at least 2 simple choices provided that are uniquely identified within the item.

### IMPORT
* Q2-L1-I11: Import single-cardinality.xml and correctly store the interaction as a choice interaction that allows for single selection.
* Q2-L1-I12: Import single-cardinality.xml and correctly stores the choices and uniquely identifies them within the item.
* Q2-L1-I13: Import single-cardinality.xml and correctly store the number of max-choices and min-choices.
* Q2-L1-I14: **Invalid Example**  For single-cardinality-invalid.xml -- MUST display an XML validation exception.

#### Shared Vocabulary for IMPORT

* Q2-L1-I202: File **single-cardinality-sv-2a.xml** uses the class **qti-labels-none** in the qti-choice-interaction element which MUST be stored in association with the interaction.  
* Q2-L1-I203: File **single-cardinality-sv-2b.xml** uses the class **qti-labels-decimal** in the qti-choice-interaction element which MUST be stored in association with the interaction.
* Q2-L1-I204: File **single-cardinality-sv-2c.xml** uses the class **qti-labels-lower-alpha** in the qti-choice-interaction element which MUST be stored in association with the interaction.
* Q2-L1-I205: File **single-cardinality-sv-2d.xml** uses the class **qti-labels-upper-alpha** in the qti-choice-interaction element which MUST be stored in association with the interaction.

* Q2-L1-I206: File **single-cardinality-sv-3a.xml** uses the classes **qti-labels-lower-alpha** and **qti-labels-suffix-none** in the qti-choice-interaction element which MUST be stored in association with the interaction.
* Q2-L1-I207: File **single-cardinality-sv-3b.xml** uses the classes **qti-labels-lower-alpha** and **qti-labels-suffix-period** in the qti-choice-interaction element which MUST be stored in association with the interaction.
* Q2-L1-DI08: File **single-cardinality-sv-3c.xml** uses the classes **qti-labels-lower-alpha** and **qti-labels-suffix-parenthesis** in the qti-choice-interaction element which MUST be stored in association with the interaction.
* Q2-L1-I209: File **single-cardinality-sv-3d.xml** uses the classes **qti-labels-upper-alpha** and **qti-labels-suffix-none** in the qti-choice-interaction element which MUST be stored in association with the interaction.
* Q2-L1-I210: File **single-cardinality-sv-3e.xml** uses the classes **qti-labels-upper-alpha** and **qti-labels-suffix-period** in the qti-choice-interaction element which MUST be stored in association with the interaction.
* Q2-L1-I211: File **single-cardinality-sv-3f.xml** uses the classes **qti-labels-upper-alpha** and **qti-labels-suffix-parenthesis** in the qti-choice-interaction element which MUST be stored in association with the interaction.

* Q2-L1-I212: File **single-cardinality-sv-3g.xml** uses the classes **qti-labels-decimal** and **qti-labels-suffix-none** in the qti-choice-interaction element which MUST be stored in association with the interaction.
* Q2-L1-I213: File **single-cardinality-sv-3h.xml** uses the classes **qti-labels-decimal** and **qti-labels-suffix-period** in the qti-choice-interaction element which MUST be stored in association with the interaction.
* Q2-L1-I214: File **single-cardinality-sv-3i.xml** uses the classes **qti-labels-decimal** and **qti-labels-suffix-parenthesis** in the qti-choice-interaction element which MUST be stored in association with the interaction.

* Q2-L1-I215: File **single-cardinality-sv-3j.xml** uses the class **qti-labels-suffix-none** in the qti-choice-interaction element which MUST be stored in association with the interaction.  
* Q2-L1-I216: File **single-cardinality-sv-3k.xml** uses the class **qti-labels-suffix-period** in the qti-choice-interaction element which MUST be stored in association with the interaction.
* Q2-L1-I217: File **single-cardinality-sv-3l.xml** uses the class **qti-labels-suffix-parenthesis** in the qti-choice-interaction element which MUST be stored in association with the interaction.

### AUTHORING
* Q2-L1-A11: Create an interaction within an item with at least 2 choices where only one of those choices is selectable.
* Q2-L1-A12: Modify an interaction within an item with at least 2 choices where only one of those choices is selectable.

### DELIVERY

* Q2-L1-D51: For file single-cardinality.xml after ending the attempt without selecting any SimpleChoices, the **RESPONSE** Response Variable is set with the **NULL** value.
* Q2-L1-D52: For file single-cardinality.xml after ending the attempt with the SimpleChoice with identifier **choice_a** selected, the **RESPONSE** Response Variable is set with a value **choice_a**, with an **Identifier** baseType and a **Single** cardinality.
* Q2-L1-D53: For file single-cardinality.xml after ending the attempt with the SimpleChoice with identifier **choice_b** selected, the **RESPONSE** Response Variable is set with a value **choice_b**, with an **Identifier** baseType and a **Single** cardinality.
* Q2-L1-D54: For file single-cardinality.xml after ending the attempt with the SimpleChoice with identifier **choice_c** selected, the **RESPONSE** Response Variable is set with a value **choice_c**, with an **Identifier** baseType and a **Single** cardinality.
* Q2-L1-D55: For file single-cardinality.xml the candidate cannot select more than one SimpleChoice.

* Q2-L1-D56: **Invalid Example**  For single-cardinality-invalid.xml -- MUST display an XML validation exception.

#### Shared Vocabulary Classes Acceptance Criteria for DELIVERY

The qti-choice-interaction has a considerable amount of its shared vocabulary dedicated to the presentation/layout of the interaction’s associated qti-simple-choices. Each qti-simple-choice consists of a collection of elements, displayed from left to right, defined as follows:

1. A “control”; e.g., either a radio button or checkbox control, and
2. A “label”; e.g., often an alphanumeric character such as, “A”, “B”, “1”, “2”, etc., and
3. A “label suffix”; e.g., a “.” or “)” character after the label, and
4. A “description”; e.g., the HTML content contained by a qti-simple-choice element 

By default, in the absence of any shared vocabulary, the presentation of each choice control, label, label suffix, and description, is left to the implementer, with the only requirement that the choices are displayed in a single column, vertically oriented.


* Q2-L1-D201: File **single-cardinality-sv-1.xml** does not use any of the "qti-labels- " or "qti-labels-suffix- " classes in the qti-choice-interaction element. When the example is visually presented, any visually presented labels or label suffix are at the discretion of the delivery platform.  

* Q2-L1-D202: File **single-cardinality-sv-2a.xml** uses the class **qti-labels-none** in the qti-choice-interaction element. When the example is visually presented it MUST NOT display any visual labels (often an alphanumeric character) or label suffixes (often a symbol after the label) associated with any of the simple-choices.  
* Q2-L1-D203: File **single-cardinality-sv-2b.xml** uses the class **qti-labels-decimal** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in numerically ascending order (e.g., 1 2 3  etc.). In this example, the label suffix is not specified and is at the discretion of the delivery platform.
* Q2-L1-D204: File **single-cardinality-sv-2c.xml** uses the class **qti-labels-lower-alpha** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in lower-case alphabetically ascending order (e.g., a b c  etc.). In this example, the label suffix is not specified and is at the discretion of the delivery platform.
* Q2-L1-D205: File **single-cardinality-sv-2d.xml** uses the class **qti-labels-upper-alpha** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in upper-case alphabetically ascending order (e.g., A B C  etc.). In this example, the label suffix is not specified and is at the discretion of the delivery platform.

* Q2-L1-D206: File **single-cardinality-sv-3a.xml** uses the classes **qti-labels-lower-alpha** and **qti-labels-suffix-none** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in lower-case alphabetically ascending order (e.g., a b c  etc.). In this example, the label suffix MUST NOT display any label suffix.
* Q2-L1-D207: File **single-cardinality-sv-3b.xml** uses the classes **qti-labels-lower-alpha** and **qti-labels-suffix-period** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in lower-case alphabetically ascending order (e.g., a b c  etc.) followed by a label suffix, which MUST display as a period character "." .
* Q2-L1-D208: File **single-cardinality-sv-3c.xml** uses the classes **qti-labels-lower-alpha** and **qti-labels-suffix-parenthesis** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in lower-case alphabetically ascending order (e.g., a b c  etc.) followed by a label suffix, which MUST display as a closing parenthesis character ")" .
* Q2-L1-D209: File **single-cardinality-sv-3d.xml** uses the classes **qti-labels-upper-alpha** and **qti-labels-suffix-none** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in upper-case alphabetically ascending order (e.g., A B C  etc.). In this example, the label suffix MUST NOT display any label suffix.
* Q2-L1-D210: File **single-cardinality-sv-3e.xml** uses the classes **qti-labels-upper-alpha** and **qti-labels-suffix-period** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in upper-case alphabetically ascending order (e.g., A B C  etc.) followed by a label suffix, which MUST display as a period character "." .
* Q2-L1-D211: File **single-cardinality-sv-3f.xml** uses the classes **qti-labels-upper-alpha** and **qti-labels-suffix-parenthesis** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in upper-case alphabetically ascending order (e.g., A B C  etc.) followed by a label suffix, which MUST display as a closing parenthesis character ")" .

* Q2-L1-D212: File **single-cardinality-sv-3g.xml** uses the classes **qti-labels-decimal** and **qti-labels-suffix-none** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in numerically ascending order (e.g., 1 2 3  etc.). In this example, the label suffix MUST NOT display any label suffix.
* Q2-L1-D213: File **single-cardinality-sv-3h.xml** uses the classes **qti-labels-decimal** and **qti-labels-suffix-period** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in numerically ascending order (e.g., 1 2 3  etc.) followed by a label suffix, which MUST display as a period character "." .
* Q2-L1-D214: File **single-cardinality-sv-3i.xml** uses the classes **qti-labels-decimal** and **qti-labels-suffix-parenthesis** in the qti-choice-interaction element. When the example is visually presented it MUST display visual labels associated with the simple-choice options in numerically ascending order (e.g., 1 2 3  etc.) followed by a label suffix, which MUST display as a closing parenthesis character ")" .

* Q2-L1D215: File **single-cardinality-sv-3j.xml** uses the class **qti-labels-suffix-none** in the qti-choice-interaction element. When the example is visually presented it MUST NOT display any visual suffix labels associated with any of the simple-choices. In this example, the label is not specified and is at the discretion of the delivery platform.  
* Q2-L1-D216: File **single-cardinality-sv-3k.xml** uses the class **qti-labels-suffix-period** in the qti-choice-interaction element. When the example is visually presented it MUST display visual suffix labels associated with the simple-choice options as a period character ".". In this example, the label is not specified and is at the discretion of the delivery platform.
* Q2-L1-D217: File **single-cardinality-sv-3l.xml** uses the class **qti-labels-suffix-parenthesis** in the qti-choice-interaction element. When the example is visually presented it MUST display visual suffix labels associated with the simple-choice options as a closing parenthesis character ")". In this example, the label is not specified and is at the discretion of the delivery platform.

