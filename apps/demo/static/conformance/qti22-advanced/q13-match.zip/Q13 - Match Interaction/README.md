# Q-13 - Match Interaction

## Description 

This QTI 2.2 Conformance Test Sample aims at testing the **Q13 - Match Interaction** feature. 2 examples are provided to express differences in max differences. Match Example 1 is the classic QTI example from the BPIG. Match Example 2 is a newly generated item from ETS that places limits on the number of associations to 3.

| Q10                  |   |
|-----------------------|---|
| **Test Sample ID**        | Q13- Match Interaction  |
| **Test Sample Title**     | Q13 Match Interaction |
| **Related Documentation** | [QTI ASI Model - Response Processing](http://www.imsglobal.org/question/qtiv2p2p2/QTIv2p2p2-ASI-InformationModelv1p0/imsqtiv2p2p2_asi_v1p0_InfoModelv1p0.html#Root_ResponseProcessing) |

## Acceptance Criteria

### EXPORT
* Q13-L2-E1: Export a valid item with a Match Interaction with at least two simple match sets that contain at least two simple associable choices.

### IMPORT
* Q13-L2-I1: import match-example-1.xml and correctly store the data related to the interaction, including the response declaration data.
* Q13-L2-I2: import match-example-2.xml and correctly store the data related to the interaction, including the response declaration data and the max-asociations of 3.


### AUTHORING
* Q13-L2-A1: Create an interaction within an item that presents candidates with two sets of choices and allows them to create associations between pairs of choices in the two sets, but not between pairs of choices in the same set. 
*  Q13-L2-A2: Modify an interaction within an item that presents candidates with two sets of choices and allows them to create associations between pairs of choices in the two sets, but not between pairs of choices in the same set.
* Q13-L2-A3: For a match interaction, set the minimum number of associations between the two sets of choices using a non-negative number greater than zero but less or equal to the maximum number of associations.
* Q13-L2-A4: For a match interaction, set the maximum number of associations between the two sets of choices.
* Q13-L2-A5: For a match interaction choice, set the maximum number of times you can match that choice with choices from the other set.

### DELIVER
* NOTE: You do NOT need to support the shuffle attribute!

* Q13-L2-D1: Present Match example 1 (match-example-1.xml) 

* Q13-L2-D2: For delivery, Match example 2 (match-example-2.xml) should limit the number of choices to 3 associations (uses the max-associations attribute).
* Q13-L2-D3: For the choices in example 2, the candidate should be limited to placing only 2 instances of any of the first set of choices (animal attributes) into the animal types.
* Q13-L2-D4: The MatchInteraction must be bound to a response variable with base-type directedPair and either single or multiple cardinality.

