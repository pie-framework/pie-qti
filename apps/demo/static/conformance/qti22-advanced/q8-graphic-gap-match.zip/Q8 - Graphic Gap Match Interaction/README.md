# Q8 - Graphic Gap Match Interaction 
 
## Description

This QTI 2.2 Conformance Test Sample aims at testing the **Q8 - Hotspot Interaction** feature. There are two examples. One uses **GapImg** and the other use **GapText**.

| Q8                   |   |
|-----------------------|---|
| **Test Sample ID**        | q8--graphic-gap-match-interaction  |
| **Test Sample Title**     | Q8 - Graphic Gap Match Interaction |
| **Dependencies**        | I1 - responseDeclaration |
| **Related Documentation** | [QTI ASI Model - Choice Interaction](https://www.imsglobal.org/question/qtiv2p2p1/QTIv2p2p1-ASI-InformationModelv1p0/imsqtiv2p2p1_asi_v1p0_InfoModelv1p0.html#Data_ChoiceInteraction), [QTI Implementation Guide - Simple Items](https://www.imsglobal.org/question/qtiv2p2/imsqti_v2p2_impl.html#3.2)|

## Acceptance Criteria


### EXPORT

* Q8-L2-E1: Export a valid Graphic Gap Match Interaction with at least 2 qti-gap-img choices and 2 qti-associable-hotspot targets.
* Q8-L2-E2: Export a valid Graphic Gap Match Interaction with at least 2 qti-gap-text choices and 2 qti-associable-hotspot targets.

### IMPORT

* Q8-L2-I1: Import graphic-gap-match-interaction-1.xml and correctly store the main image with associated attribute data, and all the qti-gap-img choices (with match-max="1" and alt text), and all 3 associable hotspots with their data.
* Q8-L2-I2: Import graphic-gap-match-interaction-2.xml and correctly store the main image with associated attribute data, and all the qti-gap-text choices (with match-max="1"), and all 3 associable hotspots with their data.


### AUTHORING

* Q8-L2-A1: Create an interaction within an item with a set of gaps that are defined as areas (hotspots) of the graphic image and an additional set of gap choices (images, text, objects) that are defined outside the image. 
* Q8-L2-A2: Modify an interaction within an item with a set of gaps that are defined as areas (hotspots) of the graphic image and an additional set of gap choices (images, text, objects) that are defined outside the image. 
* Q8-L2-A3: For graphic gap match interaction, set the minimum number of associations between the choices and gaps as a non-negative number where that number is greater than zero AND greater than or equal to the maximum number of associations.
* Q8-L2-A4: For graphic gap match interaction, set the maximum number of associations between the choices and gaps as a non-negative number where that number is greater than or equal to the minimum number of associations.
* Q8-L2-A5: For a gap image choice in a graphic gap match interaction, set the maximum number of times you can match the choice (occurrences) with gaps as a non-negative number.
* Q8-L2-A6: For a gap text choice in a graphic gap match interaction, set the maximum number of times you can match the choice (occurrences) with gaps as a non-negative number.
* Q8-L2-A7: For an associable hot spot (a gap) in a graphic gap match interaction, set the maximum number of associations that a gap can have as a non-negative number. 
* Q8-L2-A8: For an associable hot spot (a gap) in a graphic gap match interaction, set the shape and coordinates of the hot spot.

### DELIVERY

* Q8-L2-D1: **Example graphic-gap-match-interaction-1**, Graphic Gap Match using GapImg. The delivery markup (used in the presentation of content to the candidate) includes alt text for the images used in the interaction and MUST be available to candidates using Assistive Technology. The image defined in the object tag must be visually displayed behind the hotspots, which should be visible to the candidate. It MUST be clear to the clear to the candidate which hotspot each choice has been associated with, and placed choices MUST be visually displayed over the background image. When associated, choices MUST appear wholly inside the gaps. If the candidate indicates the association by positioning the choice above the gap (drag and drop) the system MUST snap the choice to the nearest response position. The minimum score MUST be determined to be 0 for a candidate (lower-bound="0"). For no correct pairings, the score is 0. For 1 correct pairing, the score is 0. For 2 correct pairings the score is 1. For 3 correct pairings, the score is 2.
* Q8-L2-D2: **Example graphic-gap-match-interaction-2**, Graphic Gap Match using GapText. Each associable hotspot response area MUST accept only one choice (gap text). The minimum score MUST be determined to be 0 for a candidate (lower-bound="0"). For no correct pairings, the score is 0. For 1 correct pairing, the score is 0. For 2 correct pairings the score is 1. For 3 correct pairings, the score is 2.
