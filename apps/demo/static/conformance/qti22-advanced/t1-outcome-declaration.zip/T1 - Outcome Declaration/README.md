# T1 - Outcome Declaration & T9 - Outcome Processing for Tests

## Description

This QTI 2.2 Conformance Test Sample aims at testing the **T1 - Outcome Declaration** feature. It enables vendors to
test the Delivery Engine ability to deal with test level **Outcome Declarations**.

| T1 - Outcome Declaration & T9 Outcome Processing Tests |   |
|-----------------------|---|
| **Test Sample ID**        | t1-outcome-declaration-t9-outcome-processing |
| **Test Sample Title**     | T1 - Outcome Declaration & T9 Outcome Processing Tests|
| **Dependencies**          | T4 - Test Parts, T7 - Sections, I9a - Response Processing-Full, I9b - Response Processing Fixed Template |
| **Related Documentation** | [QTI ASI Model - Outcome Declaration](http://www.imsglobal.org/question/qtiv2p2p1/QTIv2p2p1-ASI-InformationModelv1p0/imsqtiv2p2p1_asi_v1p0_InfoModelv1p0.html#Root_OutcomeDeclaration) |

## Acceptance Criteria

### EXPORT
* T1-L2-E1: Export a valid test with an outcome declaration.
* T9-L2-E1: Export a valid test with outcome processing.

### IMPORT
* T1-L2-I1: import assessment.xml and record the data for the outcome declaration for the assessment.
* T9-L2-I1: import assessment.xml and record the data for the outcome processing for the assessment.


### DELIVERY
* T1-L2-D1: The variable value bound to the **SCORE_TOTAL** is by default, initialized to **0**, where base-type="float".
* T9-L2-D1: While taking the test, the variable value bound to the **SCORE_TOTAL** Outcome Declaration remains strictly equal to the amount of correctly responded **AssessmentItems** amongst the **AssessmentTest**. 
