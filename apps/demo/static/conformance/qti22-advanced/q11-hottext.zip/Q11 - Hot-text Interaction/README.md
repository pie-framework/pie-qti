# Q-11 Hot-text Interaction

## Description

This QTI 2.2 Conformance Test Sample aims at testing the **Q11 - Hot-text Interaction** feature. Two examples are provided, one with a single grammar error, the second with two grammar errors.

| Q11                  |   |
|-----------------------|---|
| **Test Sample ID**        | Q11- Hot text Interaction  |
| **Test Sample Title**     | Q11 - HotTextInteraction |
| **Related Documentation** | [QTI ASI Model - Response Processing](http://www.imsglobal.org/question/qtiv2p2p2/QTIv2p2p2-ASI-InformationModelv1p0/imsqtiv2p2p2_asi_v1p0_InfoModelv1p0.html#Root_ResponseProcessing) |

## Acceptance Criteria

### EXPORT
* Q11-L2-E1: Export a valid item with a hot text interaction with the required response-identifier attribute. The interaction MUST have at least 2 Hottext areas with the required identifier attribute

### IMPORT

* Q11-L2-I1: import hot-text-interaction-1.xml and properly store the identified text areas and number of max-choices
* Q11-L2-I2: import hot-text-interaction-2.xml and properly store the identified text areas and number of max-choices.

* Q11-L2-I101: import hottext-sv-1.xml and properly store the interaction information and class qti-input-control-hidden in association with the interaction.
* Q11-L2-I102: import hottext-sv-2.xml and properly store the interaction information (inlcuding min-choices and max-choices) and the min- and max-choices messages. 

### AUTHORING

* Q11-L2-A1: Create an interaction within an item that designates portions of text as selectable choices.
* Q11-L2-A2: Modify an interaction within an item that designates portions of text as selectable choices.
* Q11-L2-A3: For an interaction that designates portions of text as selectable choices, set the maximum number of choices to a number less than or equal to the total number of possible choices
* Q11-L2-A4: For an interaction that designates portions of text as selectable choices, set the minimum number of choices to a number less than or equal to the total number of possible choices OR less than or equal to the number of maximum choices (if smaller) AND greater than zero.

### DELIVERY

* Q11-L2-D1: hot-text-interaction-1.xml contains an example of a hot text interaction with single cardinality. The candidate MUST be restricted to selecting only a single choice. The correct response is B. All other responses are incorrect.
* Q11-L2-D2: The Second example (hot-text-interaction-2.xml) is a hot text interaction with multiple cardinality. The candidate may choose as many choices as they desire up to the max-choices. The correct response is A and B. Selecting only A or B is incorrect. Any other combinations other than A and B are incorrect.
* Q11-L2-D3: For multiple cardinality example, the delivery system should enforce the maximum choices of 2