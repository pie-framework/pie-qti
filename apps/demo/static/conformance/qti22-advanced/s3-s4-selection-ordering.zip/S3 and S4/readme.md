# S3 - Selection & S4 - Ordering

## Description

This example is taken from the QTI 2.2 BPIG and modified to exclude the use of **sub-sections (S8)** as that's an Elective feature. The resulting sample covers **S3 (selection)** and **S4 (ordering)**.

| S3 - Selection & S4 - Ordering |   |
|-----------------------|---|
| **Test Sample ID**        | s3selection_s4ordering |
| **Test Sample Title**     | S3 - Selection & S4 - Ordering |
| **Dependencies**          | T4 - Test Parts, T7 - Sections, I9a - Response Processing-Full, I9b - Response Processing Fixed Template |
| **Related Documentation** | [QTI ASI Model - Assessment Section](http://www.imsglobal.org/question/qtiv2p2p1/QTIv2p2p1-ASI-InformationModelv1p0/imsqtiv2p2p1_asi_v1p0_InfoModelv1p0.html#RootAttribute_assessmentSection) |

## Acceptance Criteria

### EXPORT
* S3-L2-E1: Export a valid test with a section that contains a qti-selections node which includes the select attribute.
* S4-L2-E1: Export a valid test with a section that contains a qti-ordering with any ordering data.

### IMPORT
* S3-L2-I1: import s3selection_s4ordering.xml and correctly store the selections data for the sections.
* S4-L2-I1: import s3selection_s4ordering.xml and correctly store the order data for the sections.
* S4-L2-I2: import s3selection_s4ordering.xml and correctly store the navigation-mode for the test part.

### AUTHORING

* S3-L2-A1: Create a test and set the number of items in a section of that test to be presented to candidates for a number less than the total number of items referenced in the section.
* S3-L2-A2: Modify a section in a test and set the number of items to be included in that section of the test to be presented to candidates for a number less than the total number of items referenced in that section.

* S4-L2-A1: Create a test and set the items within a section to be shuffled for each candidate when initiating a test session.
* S4-L2-A2: Modify a test and set the items within a section to be shuffled for each candidate when initiating a test session.
* S4-L2-A3: Modify a test and set the items within a section to NOT be shuffled for each candidate when initiating a test session.

* S4-L2-A11: Within a Test Part, set to allow for the candidate to choose to navigate to items within that part in a non-linear order.
* S4-L2-A12: Within a Test Part, set to restrict the candidate to be presented items within that part in linear order only.
