# P-7 - QTI Metadata

## Description 

This QTI 2.2 Conformance Test Sample aims at testing the **P7 - QTI Metadata** feature. The metadata is within the manifest file that provides information about the dummy item.

**Temporary** The imsmanifest with lom.xml file is the same example only it also contains LOM metadata, which is not a requirement for packaging at level 2.

| P7                  |   |
|-----------------------|---|
| **Test Sample ID**        | P7- QTI Metadata  |
| **Test Sample Title**     | P7 QTI Metadata |
| **Related Documentation** | should link to CP profile for QTI 3|

## Acceptance Criteria

* At this time there are no specific acceptance criteria for this feature.

