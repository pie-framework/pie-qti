# I17 - Composite Item and I9a - Full Response Processing

## Description

This QTI 2.2 Conformance Test Sample aims at testing the **I17 - Composite Item** feature. It enables vendors to
test the Delivery application to serve an Item that contains more than one Interaction. It also demonstrates support of **I9a - Full Response Processing**.

| T4                  |   |
|-----------------------|---|
| **Test Sample ID**        | I17- Composite Item  |
| **Test Sample Title**     | T7 - Sections |
| **Related Documentation** | [QTI ASI Model - Response Processing](http://www.imsglobal.org/question/qtiv2p2p2/QTIv2p2p2-ASI-InformationModelv1p0/imsqtiv2p2p2_asi_v1p0_InfoModelv1p0.html#Root_ResponseProcessing) |

## Acceptance Criteria

### EXPORT
* I17-L2-E1: Export a valid package that contains an item with more than one interaction where each interaction has a unique identifier. Interactions MUST NOT be nested within each other.
* I9-L2-E1: Export a valid package that contains an item where the response processing using "full" response processing (not template based).

### IMPORT
* I17-L2-I1: Import shakespeare_biography.xml and store the item with both interactions including correct associations for each interaction for the responses, outcome declaration, mapping.
ions.
* I9-L2-I1: Import shakespeare_biography.xml and store the response processing in association with the item.

### AUTHORING
* I17-L2-A1: Create an item that has more than one interaction where each interaction has a unique identifier and the response identifiers are unique within the item.
* I17-L2-A2: Modify the interactions in an item that has more than one interaction.

### DELIVERY
#### I17 Composite Item
* I17-L2-D1: Display shakespeare_biography.xml where there are 3 distinct interactions presented to the candidate (2 choice and 1 text entry). 
#### I9 Response processing FULL
There are 3 interactions in the item:  two inline choice interactions (response_1 and response_2) and one text entry interaction (response_3).

The response processing evaluates the responses for each of the interactions and subscores them individually, storing each subscore in an
outcome variable (SCORE_1, SCORE_2, and SCORE_3).  As each subscore is computed, its value is added to the overall item SCORE outcome variable by using the <qti-sum> operator.
* I9-L2-D1: The system MUST score interaction response_1 as follows (SCORE_1 is evaluated using the <qti-match> operator): 
   * SCORE_1 evaluates to 1 if response_1 equals the identifier choice_1; 
   * SCORE_1 evaluates to 0 if response_1 is any other identifier, or is null.
* I9-L2-D2: The system MUST score interaction response_2 as follows (SCORE_2 is evaluated using the <qti-match> operator): 
   * SCORE_2 evaluates to 1 if response_2 equals the identifier choice_4; 
   * SCORE_2 evaluates to 0 if response_2 is any other identifier, or is null.
* I9-L2-D3: The system MUST score interaction response_3 as follows (SCORE_3 is evaluated using the <qti-map-response> operator):
   * SCORE_3 evaluates to 1 if response_3 equals the string "poet" or the string "playwright";
   * SCORE_3 evaluates to 0.5 if response_3 equals the string "writer";
   * SCORE_3 evaluates to 0 if response_3 contains any other string, or is null.

* I9-L2-D11: The system MUST score the assessment as follows (SCORE is computed by summing; i.e., using the <qti-sum> operator, each interaction's subscore): 
  * IF response_1 = choice_1, response_2 = choice_4, and response_3 = poet or playwright THEN SCORE = 3; 
  * IF response_1 = null, response_2 = null, and response_3 = null THEN SCORE = 0; 
  * IF response_1 = choice_2, response_2 = choice_5, and response_3 = writer THEN SCORE = 0.5
