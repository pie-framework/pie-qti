# Q2 - Choice Interaction - Single Cardinality - Invalid Examples

## Description

These two examples exercise a delivery application's ability to interpret the semantics around cardinality and min/maxChoices, and throw validation errors accordingly.

| Q2                    |   |
|-----------------------|---|
| **Test Sample ID**        | q2-choice-interaction-single-cardinality  |
| **Test Sample Title**     | Q2 - Choice Interaction - Single Cardinality |
| **Dependencies**          | I1 - responseDeclaration |
| **Related Documentation** | [QTI ASI Model - Choice Interaction](https://www.imsglobal.org/question/qtiv2p2p1/QTIv2p2p1-ASI-InformationModelv1p0/imsqtiv2p2p1_asi_v1p0_InfoModelv1p0.html#Data_ChoiceInteraction), [QTI Implementation Guide - Simple Items](https://www.imsglobal.org/question/qtiv2p2/imsqti_v2p2_impl.html#3.2)|

## Acceptance Criteria

### IMPORT
* **Q2-L2-I51** Invalid Cardinality example choice-interaction-invalid-cardinality.xml MUST display a QTI validation error because the cardinality of responseDeclaration is single, yet maxChoices is greater than 1.
* **Q2-L2-I52** Invalid minChoices example choice-interaction-invalid-minchoices.xml MUST display a QTI validation error because minChoices exceeds maxChoices, thus making it impossible to enter a valid answer/attempt.

### EXPORT, AUTHORING, DELIVERY, SCORING 
* The are no other Acceptance Criteria for Advancesd Level Choice Interaction for these capabilities.
