# Q13 - Inline Choice Interaction

## Description

This QTI 2.2 Conformance Test Sample aims at testing the **Q13 - Inline Choice Interaction** feature. One example has a single inline choice interaction. A second example uses MathML within the itemBody and choices. A third example is a composite item with 2 inline choice interactions, requiring full response processing

**Known Invalid Example error:** The cardinality of the responseDeclaration variable for the inlineChoiceInteraction must be single cardinality.  Multiple cardinality should throw an exception.


| Q13                   |   |
|-----------------------|---|
| **Test Sample ID**        | q13-inline-choice-interaction  |
| **Test Sample Title**     | Q13 - Inline Choice Interaction |
| **Dependencies**          | I1 - responseDeclaration, I2 - outcomeDeclaration, I7 - Item Body, I9a - Response Processing Full, I9b - Response Processing Template |
| **Related Documentation** | [QTI ASI Model - Inline Choice Interaction](https://www.imsglobal.org/question/qtiv2p2p1/QTIv2p2p1-ASI-InformationModelv1p0/imsqtiv2p2p1_asi_v1p0_InfoModelv1p0.html#Data_InlineChoiceInteraction), [QTI Implementation Guide - Simple Items](https://www.imsglobal.org/question/qtiv2p2/imsqti_v2p2_impl.html#3.2)|

 ## Acceptance Criteria

 
### EXPORT
* Q12-L2-E1: Export a valid item with an inline choice interaction with the required response-identifier attribute and at least 2 qti-inline-choice response options (with required identifier attribute).
 
### IMPORT
* Q12-L2-I1: import inline-choice-composite.xml and properly store the item with both interactions with their unique response-identifiers and all the inline-choices and all of their identifiers.
* Q12-L2-I2: import inline-choice-mathml.xml and store the interaction and the MathML within the inline-choices.
* Q12-L2-I3: import inline-choice.xml and properly store the interaction with the correct response of Y

* Q12-L2-I21: **Invalid Example** for inline-choice-invalid.xml the system MUST display an XML validation exception.



 ### AUTHORING
 
* Q12-L2-A1: Create an interaction within an item that allows the candidate to pick from a list of possible choices in the context of surrounding text.
* Q12-L2-A2: Modify an interaction within an item that allows the candidate to pick from a list of possible choices in the context of surrounding text.

 
### DELIVERY

* Q12-L2-D1: For inline-choice-composite.xml, after ending the attempt without selecting any InlineChoices, both of the Response Variables (RESPONSE and RESPONSE_1) are set with the value **null**.
*  Q12-L2-D2: For inline-choice-composite.xml, the choices are displayed "inline" (within the flow of the paragraph), and not displayed as a separate block. 
*  Q12-L2-D3: For inline-choice-composite.xml, after ending the attempt by selecting the InlineChoice with **correctResponse**, in this case, **York**, the **RESPONSE** Response Variable is set with the **responseIdentifier** corresponding to that value, in this case, **Y**. The **SCORE** Outcome Variable is set with a value of **1** with **float** baseType.
*  Q12-L2-D4: For inline-choice-composite.xml, ending the attempt with any other InlineChoice, will set the **SCORE** Outcome Variable with a value of **0** with **float** baseType and **RESPONSE** Response Variable with the corresponsing **responseIdentifier**.  
*  Q12-L2-D5: For inline-choice-composite.xml the **RESPONSE** Response Variable is set with the **responseIdentifier** corresponding to the value selected for the first inlineChoice interaction for each of the InlineChoices offered, or null if none were selected. Similarly, the RESPONSE_1 Response Variable is set with the responseIdentifier corresponding to the value selected for the second inlineChoice interaction for each of the InlineChoices offered, or null if none were selected The SCORE Outcome Variable must have **float** baseType and have the value **2** if the correct response was selected for both inline choice interactions, the value **1** if the correct choice was selected for only one of the inline choice interactions, and **0** if the correct choice was not selected for any of the inline choice interactions.
* Q12-L2-D21: **Invalid Example** This should display a QTI validation exception: multiple cardinality not permitted.
