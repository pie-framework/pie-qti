# T5 - Test Parts - Item Session Control

## Description

This QTI 2.2 Conformance Test Sample aims at testing the **T5 - Test Parts - Item Session Control** feature. It enables vendors to
test the Delivery Engine ability override default Item Session Control configuration. This Conformance Test
focuses on giving an unlimited number of **attempts** for each **AssessmentItem** composing the **AssessmentTest**.

| T5 - Test Parts - Item Session Control |   |
|-----------------------|---|
| **Test Sample ID**        | t5-test-parts-item-session-control |
| **Test Sample Title**     | T5 - Test Parts - Item Session Control |
| **Dependencies**          | T7 - Sections |
| **Related Documentation** | [QTI ASI Model - Test Part](http://www.imsglobal.org/question/qtiv2p2p1/QTIv2p2p1-ASI-InformationModelv1p0/imsqtiv2p2p1_asi_v1p0_InfoModelv1p0.html#Root_TestPart), [QTI ASI Model - Item Session Control](http://www.imsglobal.org/question/qtiv2p2p1/QTIv2p2p1-ASI-InformationModelv1p0/imsqtiv2p2p1_asi_v1p0_InfoModelv1p0.html#DataAttribute_AssessmentItemRef_itemSessionControl) |

## Acceptance Criteria

### EXPORT
* T5-L2-E1: export a valid test with at least 1 test part that has at least one item session control parameter.

### IMPORT
* T5-L2-I1: import assessment.xml and store the item session control data for the test part (identifier="testPart-1).

### AUTHORING

* T5-L2-A1: Create a test and set the number of maximum attempts a candidate can have for the test.
* T5-L2-A2: Modify a test and set the number of maximum attempts a candidate can have for the test.
* T5-L2-A3: Create a test and set whether candidates can skip items (candidate does not provide a response) during the assessment session for the test.
* T5-L2-A4: Modify a test and set whether candidates can skip items during the assessment session for the test.

### DELIVERY

* T5-L2-D1: for assessment.xml testPart-1, for any of the assessment items within the test part is being responded, the number of attempts per **AssessmentItem** per candidate is unlimited.
