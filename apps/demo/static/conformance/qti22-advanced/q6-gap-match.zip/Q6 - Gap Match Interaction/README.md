# Q-6 Gap Match Interaction

## Description

This QTI 2.2 Conformance Test Sample aims at testing the **Q11 - Gap Match Interaction** feature. Three examples are provided:
* gap-match-example-1 - Richard III (Take 1)
* gap-match-example-2 - Contains MathML in the gap choices
* gap-match-example-3 - Contains a Table element which encloses the gapssingle grammar error, the second with two grammar errors.

| Q6                  |   |
|-----------------------|---|
| **Test Sample ID**        | Q6- Gap Match Interaction  |
| **Test Sample Title**     | Q6 - Gap Match Interaction |
| **Related Documentation** | [QTI ASI Model - Response Processing](http://www.imsglobal.org/question/qtiv2p2p2/QTIv2p2p2-ASI-InformationModelv1p0/imsqtiv2p2p2_asi_v1p0_InfoModelv1p0.html#Root_ResponseProcessing) |

## Acceptance Criteria

### EXPORT
* Q6-L2-E1: Export a valid Gap Match Interaction with at least 2 gap text choices and 1 gap identifier.
### IMPORT
* Q6-L2-I1: import gap-match-example-1.xml including the qti-gap-text choices (match-max="1") and the correctly identified qti-gap targets.
* Q6-L2-I2: import gap-match-example-2.xml including the max-associations (4) the qti-gap-text choices (match-max="1") as MathML and the correctly identified qti-gap targets.
* Q6-L2-I3: import gap-match-example-3.xml including the max-associations (4) the qti-gap-text choices (match-max="0" meaning unlimited) and the correctly identified qti-gap targets.
* Q6-L2-I101: import gap-match-example-sv-1.xml including 4 interactions with their qti-gap-text choices and qti-gap targets AND the classes indicated where the qti-gap-text choices are to be visually positioned (qti-choice-top, etc.).
* Q6-L2-I102: import gap-match-example-sv-2.xml with their qti-gap-text choices and qti-gap targets AND the qti-choice-top class AND specified container width of 200.
* Q6-L2-I103: import gap-match-example-sv-3.xml  with their qti-gap-text choices and qti-gap targets AND the min- and max-associations data AND the min/max selections message content.
* Q6-L2-I104: import gap-match-example-sv-4.xml ith their qti-gap-text choices and qti-gap targets AND the qti-input-width-# classes in association with the correct qti-gap elements.

### AUTHORING
* Q6-L2-A1: Create an interaction within an item that allows the candidate to associate choices (as images or text) with gaps within a block of text.
* Q6-L2-A2: Create an interaction within an item that allows the candidate to associate choices (as images or text) with gaps within a block of text.
* Q6-L2-A3: For a gap match interaction, set the minimum number of associations between choices and gaps as a non-negative number greater than zero and less or equal to the maximum number of associations.
* Q6-L2-A4: For a gap match interaction, set the maximum number of associations between choices and gaps as a non-negative number greater than or equal to the minimum number of associations.
*  Q6-L2-A5: For the gap text choices or gap image choices in a gap match interaction, set the maximum number of times you can match a choice (occurrences) with gaps as a non-negative number.


### DELIVERY
* Q6-L2-D1: For gap-match-example-1.xml, each Gap can have at most one choice associated with it.
* Q6-L2-D2: For gap-match-example-1.xml, uses a scoring template 
* Q6-L2-D3: For gap-match-example-2.xml, delivery/presentation systems MUST visually present the Math as equations, not as MathML. The MathML MUST be programmatically available for Assistive Technology.
* Q6-L2-D4: For gap-match-example-3.xml, delivery/presentation systems MUST score each correct pairing as 1 point with a maximum of 4 points.


