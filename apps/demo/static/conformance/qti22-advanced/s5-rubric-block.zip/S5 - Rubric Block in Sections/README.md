# S5 - Rubric Block in Sections 

## Description

This QTI 2.2 Conformance Test Sample aims at testing the **S5 - Rubric Block - HTML** feature. It enables vendors to
test the Delivery Engine ability to deliver a test with 3 sections, each of them containing a simple HTML based rubric
block to be displayed. This also includes feature **T12 - Multiple Sections in a Test Part**.

| S5a                   |   |
|-----------------------|---|
| **Test Sample ID**        | s5-rubric-block-html  |
| **Test Sample Title**     | S5 - Rubric Block - HTML |
| **Dependencies**        | T4 - Test Parts, T7 - Sections |
| **Related Documentation** | [QTI ASI Model - Rubric Block Class Description](http://www.imsglobal.org/question/qtiv2p2p1/QTIv2p2p1-ASI-InformationModelv1p0/imsqtiv2p2p1_asi_v1p0_InfoModelv1p0.html#Data_RubricBlock) |

## Acceptance Criteria

### EXPORT
* S5-L2-E1: Export a valid test with a section that has at least one rubric block.

### IMPORT
* S5-L2-I1: import assessment.xml from the S5-RubricBlock-Sections-Package.zip package and correctly store the rubric blocks for the 3 sections.

### AUTHORING

* S5-L2-A1: Create a body of content intended for a candidate in a test section where that content is not within an item and is applicable to all the items within that section.

* S5-L2-A3: Create content intended for a non-candidate viewer role within a section of a test where that content is not within an item and is applicable to all the items within that section.

### DELIVERY

* S5-L2-D1: from assessment.xml, the first rubric block with content "Rubric Block for **Section 1**" is displayed in the context to a candidate in relation to the questions within the section (Question 1). The rubric block content may be presented prior to the question(s), or on the same screen as the question(s) within the section.
* S5-L2-D2: from assessment.xml, the first rubric block with content "Rubric Block for **Section 2**" is displayed in the context to a candidate in relation to the questions within the section (Question 2). The rubric block content may be presented prior to the question(s), or on the same screen as the question(s) within the section.
* S5-L2-D3: from assessment.xml, the first rubric block with content "Rubric Block for **Section 3**" is displayed in the context to a candidate in relation to the questions within the section (Question 3). The rubric block content may be presented prior to the question(s), or on the same screen as the question(s) within the section.

