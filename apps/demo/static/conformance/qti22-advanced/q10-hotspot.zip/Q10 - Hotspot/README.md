# Q-10 - Hotspot Interaction

## Description 

This QTI 2.2 Conformance Test Sample aims at testing the **Q10 - Hotspot Interaction** feature. 3 examples are provided to express differences in hotspot shapes and cardinality.

| Q10                  |   |
|-----------------------|---|
| **Test Sample ID**        | Q10- Hotspot Interaction  |
| **Test Sample Title**     | Q10 Hotspot Interaction |
| **Related Documentation** | [QTI ASI Model - Response Processing](http://www.imsglobal.org/question/qtiv2p2p2/QTIv2p2p2-ASI-InformationModelv1p0/imsqtiv2p2p2_asi_v1p0_InfoModelv1p0.html#Root_ResponseProcessing) |

## Acceptance Criteria


### EXPORT
* Q10-L2-E1: Export a valid item containing a hotspot interaction with the required attribute response-identifier. The interaction MUST contain at least 2 qti-hotspot-choice(s) with identifier, coords, and shape attributes.

### IMPORT
* Q10-L2-I1: Import hotspot-interaction-multiple.xml item and store the choices and attribute data correctly.
* Q10-L2-I2: Import hotspot-interaction-shapes.xml item and store the choices and attribute data correctly.
* Q10-L2-I3: Import hotspot-interaction-single.xml item and store the choices and attribute data correctly.

* Q10-L2-I101: Import hotspot-sv-1.xml item and store the choices and attribute data correctly AND the class qti-selections-light in asssociation with the interaction.
* Q10-L2-I102: Import hotspot-sv-2.xml item and store the choices and attribute data correctly (min-choices & max-choices) AND the min- and max-selections messages content associated with the interaction. 

# AUTHORING

* Q10-L2-A1: Create an interaction within an item that designates portions of an image as choices.
* Q10-L2-A2: modify an interaction within an item that designates portions of an image as choices.
* Q10-L2-A3: For an interaction that allows for selection of portions of an image as choices, designate the shape and location for any of the possible choices 
* Q10-L2-A4: For an interaction that allows for selection of portions of an image as choices, set the maximum number of choices to a number less than or equal to the total number of possible choices
* Q10-L2-A5: For an interaction that allows for selection of portions of an image as choices, set the minimum number of choices to a number less than or equal to the total number of possible choices OR less than or equal to the number of maximum choices (if smaller) AND greater than zero.

### DELIVERY

* Q10-L2-D1: A multiple cardinality example (hotspot-interaction-multiple.xml) is taken from the Best Practices Guide. The candidate may choose as many choices as they desire up to the max-choices. The hotspot choices MUST be circles placed at the coordinates specified. The only correct response is selecting A,B,D.
* Q10-L2-D2: For item hotspot-interaction-shapes.xml delivery systems MUST render the selection shapes as specified by coordinates (polygon shapes) in the interaction markup code. The candidate MUST select only a single choice. The correct response is i4. All other responses are incorrect.
* Q10-L2-D3: A single cardinality example (hotspot-interaction-single.xml) is taken from the Best Practices Guide. The candidate MUST BE restricted to selecting only a single choice. The hotspot choices MUST be circles placed at the coordinates specified. The correct answer is C. All other responses are incorrect.
